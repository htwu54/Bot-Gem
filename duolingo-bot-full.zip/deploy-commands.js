const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { token } = require('./config.json');

// Thay thế bằng ID thật
const CLIENT_ID = 'YOUR_CLIENT_ID';
const GUILD_ID = 'YOUR_GUILD_ID';

const commands = [];

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    if ('data' in command && 'execute' in command) {
        commands.push(command.data.toJSON());
    }
}

const rest = new REST().setToken(token);

(async () => {
    try {
        console.log('🔄 Đang đăng ký các slash command...');

        await rest.put(
            Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
            { body: commands },
        );

        console.log('✅ Đăng ký slash command thành công!');
    } catch (error) {
        console.error('❌ Lỗi khi đăng ký command:', error);
    }
})();
