const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');

const limits = {
    '1321811479565172758': Infinity,
    '1321811175960215562': 9000,
    '1362791178008920115': 1000,
    '1362791293276782935': 900
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('farm')
        .setDescription('Tự động farm gem Duolingo')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Số gem muốn farm')
                .setRequired(true)),
    async execute(interaction) {
        const amount = interaction.options.getInteger('amount');
        const userId = interaction.user.id;
        const roles = interaction.member.roles.cache;
        const data = JSON.parse(fs.readFileSync('duolingo.json', 'utf8'));
        const user = data[userId];

        if (!user || !user.jwt || !user.uuid) {
            return interaction.reply({ content: '❌ Bạn chưa đăng nhập. Dùng lệnh /login trước.', ephemeral: true });
        }

        const userLimit = Object.entries(limits).reduce((max, [role, limit]) => {
            return roles.has(role) ? Math.max(max, limit) : max;
        }, 0);

        if (userLimit !== Infinity && amount > userLimit) {
            return interaction.reply({ content: `❌ Bạn chỉ có thể farm tối đa ${userLimit} gems.`, ephemeral: true });
        }

        await interaction.reply(`🔁 Đang bắt đầu farm ${amount} gems...`);

        let gems = 0;
        for (let i = 0; i < amount; i++) {
            fetch(`https://www.duolingo.com/2017-06-30/users/${user.uuid}/rewards/CAPSTONE_COMPLETION-6a459295_f41c_38d9_91ba_ddd5f57d014d-2-GEMS`, {
                method: 'PATCH',
                headers: {
                    accept: 'application/json',
                    authorization: \`Bearer \${user.jwt}\`,
                    'content-type': 'application/json',
                    Referer: 'https://www.duolingo.com/practice'
                },
                body: JSON.stringify({ amount: 0, consumed: true, skillId: "5f08f69597ce7cd1663401c41a5223ac", type: "mission" })
            }).then(() => {}).catch(() => {});
            gems++;
            await new Promise(res => setTimeout(res, 1));
        }

        interaction.followUp(`✅ Đã farm xong ${gems} gems.`);
    }
};
