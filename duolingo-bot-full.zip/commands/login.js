const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('login')
        .setDescription('Lưu token Duolingo')
        .addStringOption(option =>
            option.setName('jwt')
                .setDescription('Token JWT của bạn')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('uuid')
                .setDescription('UUID của bạn')
                .setRequired(true)),
    async execute(interaction) {
        const jwt = interaction.options.getString('jwt');
        const uuid = interaction.options.getString('uuid');
        const data = JSON.parse(fs.readFileSync('duolingo.json', 'utf8'));
        data[interaction.user.id] = { jwt, uuid };
        fs.writeFileSync('duolingo.json', JSON.stringify(data, null, 2));
        await interaction.reply({ content: '✅ Đăng nhập thành công!', ephemeral: true });
    }
};
